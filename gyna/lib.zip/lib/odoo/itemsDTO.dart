


import 'package:flutter/cupertino.dart';
import 'package:object_mapper/object_mapper.dart';

class ItemsDTO with Mappable{

  int id;
  var controllerItemName =  TextEditingController(text:'');

  @override
  void mapping(Mapper map) {
    map("id", id, (v) => id = v);
    map("name", controllerItemName.text, (v) => controllerItemName.text = v.toString());
  }
}

class ItemDTO{
  int id;
  var controllerItemName =  TextEditingController(text:'');

  ItemDTO({this.id, this.controllerItemName});
}


class ItemListDTO with Mappable{

  // String model = "res.partner";

  int length;
  List<ItemsDTO> itemsList ;

  @override
  void mapping(Mapper map) {
    map("length", length, (v) => length = v);
    map<ItemsDTO>("records", itemsList, (v) => itemsList = v);
  }
}