import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:gyna/assets/constants.dart';
import 'package:gyna/screens/home_subscreen/home_buttons.dart';
import 'package:gyna/screens/subscreens/drawer_subScreen.dart';
import 'package:odoo_api/odoo_api.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    //var screenHeight = MediaQuery.of(context).size.height;
    //var screenWidth = MediaQuery.of(context).size.width;
    //6-11-1972
    //PageController controller = PageController(initialPage: 1);

    return Scaffold(
      appBar: kAppBar2,
      drawer: DrawerSubScreen(),
      body: Container(
        decoration: kBackgroundImage,
        child: GridView.count(
          crossAxisCount: 2,
          // shrinkWrap: true,
          childAspectRatio: 100/75,
          children: [
            HomeButtons(
              iconName:  FontAwesomeIcons.userPlus,
              title: "Add Patient",
              path: '/addPatient',
            ),
            HomeButtons(
              iconName:  FontAwesomeIcons.userEdit,
              title:  "view Patient",
              path: '/viewPatient',
            ),
            HomeButtons(
              iconName:  FontAwesomeIcons.hospital,
              title:  "Add Visit",
              path: '/addVisit',
            ),
            HomeButtons(
              iconName:  FontAwesomeIcons.userEdit,
              title:  "view Visit",
              path: '/viewVisit',
            ),
            HomeButtons(
              iconName:  FontAwesomeIcons.userEdit,
              title:  "Add Husband",
              path: '/addHusband',
            ),

            HomeButtons(
              iconName:  FontAwesomeIcons.flask,
              title:  "Add Lab",
              path: '/addLab',
            ),
            HomeButtons(
              iconName:  FontAwesomeIcons.pills,
              title:  "Add medicine",
              path: '/addMedicine',
            ),

          ],
        ),
      ),
    );
  }
}
